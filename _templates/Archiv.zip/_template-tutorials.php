<?php
/*
Template Name: Tutorials
*/

$context = Timber::get_context();
$post = new TimberPost();
$context['post'] = $post;

$tutorials = Timber::get_posts([
	'post_type' => 'tutorial',
	'order_by' => 'menu_order',
	'order' => 'ASC'
]);
$context['tutorials'] = $tutorials;

Timber::render(array('page-tutorials.twig', 'page.twig'), $context);