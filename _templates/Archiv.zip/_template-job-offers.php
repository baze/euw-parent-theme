<?php
/*
Template Name: Job Offers
*/

$context = Timber::get_context();
$post = new TimberPost();
$context['post'] = $post;

$jobs = Timber::get_posts(['post_type' => 'job-offer', 'order_by' => 'title', 'order' => 'ASC']);
$context['jobs'] = $jobs;

Timber::render(array('page-job-offers.twig', 'page.twig'), $context);